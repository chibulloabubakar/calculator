package com.example.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private EditText one;
    private EditText two;
    private TextView Results;
    private Button add,sub,mult,div,mod,power;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        one=(EditText) findViewById(R.id.one);
        two=(EditText) findViewById(R.id.two);
        Results=(TextView) findViewById(R.id.Results);
        add = (Button)findViewById(R.id.add );
        add.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                int Num1,Num2,Result;
                Num1 = Integer.parseInt(one.getText().toString());
                Num2 = Integer.parseInt(two.getText().toString());
                Result = Num1 + Num2;
                Results.setText(Integer.toString(Result));
            }
        });
        sub = (Button)findViewById(R.id.sub );
        sub.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                int Num1,Num2,Result;
                Num1 = Integer.parseInt(one.getText().toString());
                Num2 = Integer.parseInt(two.getText().toString());
                Result = Num1 - Num2;
                Results.setText(Integer.toString(Result));
            }
        });
        mult = (Button)findViewById(R.id.mult );
        mult.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                int Num1,Num2,Result;
                Num1 = Integer.parseInt(one.getText().toString());
                Num2 = Integer.parseInt(two.getText().toString());
                Result = Num1 * Num2;
                Results.setText(Integer.toString(Result));
            }
        });
        div = (Button)findViewById(R.id.div );
        div.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                int Num1,Num2,Result;
                Num1 = Integer.parseInt(one.getText().toString());
                Num2 = Integer.parseInt(two.getText().toString());
                Result = Num1 / Num2;
                Results.setText(Integer.toString(Result));
            }
        });
        mod = (Button)findViewById(R.id.mod );
        mod.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                int Num1,Num2,Result;
                Num1 = Integer.parseInt(one.getText().toString());
                Num2 = Integer.parseInt(two.getText().toString());
                Result = Num1 % Num2;
                Results.setText(Integer.toString(Result));
            }
        });
        power = (Button)findViewById(R.id.power );
        power.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                int Num1,Num2,Result;
                Num1 = Integer.parseInt(one.getText().toString());
                Num2 = Integer.parseInt(two.getText().toString());
                Result = Num1 ^ Num2;
                Results.setText(Integer.toString(Result));
            }
        });

    }
}